/* Link-time-only placeholder for __android_log_print. Real liblog.so on-device is used at runtime. */
int __android_log_print(int prio, const char *tag, const char *fmt, ...) { (void)prio;(void)tag;(void)fmt; return 0; }
