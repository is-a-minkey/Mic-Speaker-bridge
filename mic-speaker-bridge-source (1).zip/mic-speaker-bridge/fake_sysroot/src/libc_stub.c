/* Link-time-only placeholder. Never shipped, never executed.
   Real memcpy/memset come from the device's actual libc.so at runtime. */
#include <stddef.h>
void *memcpy(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; return d; }
void *memset(void *d, int c, size_t n) { (void)d;(void)c;(void)n; return d; }
void *memmove(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; return d; }

/* ARM32 (armeabi-v7a) only: bionic's libc.so separately exports these
 * "Run-time ABI for the ARM Architecture" helpers (confirmed against AOSP
 * bionic commit bb5730e, "Move __aeabi_ which are not in libgcc.a to
 * LIBC"). LLVM's ARM32 backend emits calls to *these* symbols - not plain
 * memcpy/memset - for compiler-generated block copies such as local
 * struct/array initializer-list copies, so they need to be resolvable
 * even though nothing in this project calls them by name directly. */
void __aeabi_memcpy(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memcpy4(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memcpy8(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memmove(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memmove4(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memmove8(void *d, const void *s, size_t n) { (void)d;(void)s;(void)n; }
void __aeabi_memset(void *d, size_t n, int c) { (void)d;(void)n;(void)c; }
void __aeabi_memset4(void *d, size_t n, int c) { (void)d;(void)n;(void)c; }
void __aeabi_memset8(void *d, size_t n, int c) { (void)d;(void)n;(void)c; }
void __aeabi_memclr(void *d, size_t n) { (void)d;(void)n; }
void __aeabi_memclr4(void *d, size_t n) { (void)d;(void)n; }
void __aeabi_memclr8(void *d, size_t n) { (void)d;(void)n; }
int __aeabi_atexit(void *object, void (*destructor)(void *), void *dso_handle) {
    (void)object;(void)destructor;(void)dso_handle; return 0;
}
