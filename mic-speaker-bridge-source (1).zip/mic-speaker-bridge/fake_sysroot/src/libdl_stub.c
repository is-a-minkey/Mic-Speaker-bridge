/* Link-time-only placeholder for dlopen/dlsym. Real libdl.so on-device is used at runtime. */
void *dlopen(const char *f, int m) { (void)f;(void)m; return (void*)0; }
void *dlsym(void *h, const char *s) { (void)h;(void)s; return (void*)0; }
