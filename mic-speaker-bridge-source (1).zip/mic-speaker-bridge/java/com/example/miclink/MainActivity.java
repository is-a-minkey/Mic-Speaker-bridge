package com.example.miclink;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;

/**
 * Mic -> speaker low-latency passthrough built on OpenSL ES, with a gain
 * slider, an output-route chooser and a level meter.
 *
 * Output routing (Android 5.0 has no per-stream "preferred device" API, so
 * this uses the platform's communication routing): the native player is a
 * STREAM_VOICE_CALL stream, and while the bridge runs the audio mode is
 * MODE_IN_COMMUNICATION, so
 *   - setSpeakerphoneOn(true)  -> loudspeaker
 *   - setSpeakerphoneOn(false) -> wired headset if plugged in, else earpiece
 *   - startBluetoothSco()      -> Bluetooth headset (call audio)
 * The previous audio mode / speakerphone state is restored on Stop.
 *
 * targetSdkVersion is pinned to 21 (see AndroidManifest.xml): on API levels
 * <= 22 all manifest-declared permissions, including RECORD_AUDIO, are
 * granted at install time, so no runtime permission-request code is needed.
 */
public class MainActivity extends Activity {

    // ---- native library ----------------------------------------------------
    private static boolean nativeLibLoaded = false;
    private static String nativeLibLoadError = null;

    static {
        try {
            System.loadLibrary("audiobridge");
            nativeLibLoaded = true;
        } catch (Throwable t) {
            // Catches UnsatisfiedLinkError (missing .so for this ABI, a
            // symbol that failed to resolve at load time, etc.) so the
            // failure is visible on screen instead of crashing outright.
            nativeLibLoadError = t.getClass().getSimpleName() + ": " + t.getMessage();
        }
    }

    // Every method here needs a matching Java_com_example_miclink_MainActivity_*
    // export in native/src/jni_bridge.cpp (build.sh verifies this).
    private static native boolean nativeInit(int scoMode);
    private static native void nativeStart();
    private static native void nativeStop();
    private static native void nativeShutdown();
    private static native void nativeSetGainPercent(int percent);
    private static native int nativeGetPeakAndReset();
    private static native int nativeGetLastErrorStep();
    private static native int nativeGetLastErrorCode();
    private static native int nativeGetConfigsAttempted();
    private static native int nativeGetSelectedSampleRate();
    private static native int nativeGetSelectedChannels();

    // Index must match the InitStep enum in native/src/audio_engine.cpp exactly.
    private static final String[] STEP_NAMES = {
            "none",
            "dlopen(libOpenSLES.so)",
            "dlsym(slCreateEngine)",
            "resolve required interface ids",
            "slCreateEngine",
            "Realize(engine)",
            "GetInterface(SL_IID_ENGINE)",
            "CreateOutputMix",
            "Realize(outputMix)",
            "CreateAudioRecorder",
            "Realize(recorder)",
            "GetInterface(SL_IID_RECORD)",
            "GetInterface(bufferqueue, recorder)",
            "RegisterCallback(recorder)",
            "CreateAudioPlayer",
            "Realize(player)",
            "GetInterface(SL_IID_PLAY)",
            "GetInterface(bufferqueue, player)",
    };

    // SLresult values, from the OpenSL ES 1.0.1 spec (SL_RESULT_* in OpenSLES.h).
    private static String slResultName(int code) {
        switch (code) {
            case -1: return "n/a";
            case 0: return "SL_RESULT_SUCCESS";
            case 1: return "SL_RESULT_PRECONDITIONS_VIOLATED";
            case 2: return "SL_RESULT_PARAMETER_INVALID";
            case 3: return "SL_RESULT_MEMORY_FAILURE";
            case 4: return "SL_RESULT_RESOURCE_ERROR";
            case 5: return "SL_RESULT_RESOURCE_LOST";
            case 6: return "SL_RESULT_IO_ERROR";
            case 7: return "SL_RESULT_BUFFER_INSUFFICIENT";
            case 8: return "SL_RESULT_CONTENT_CORRUPTED";
            case 9: return "SL_RESULT_CONTENT_UNSUPPORTED";
            case 10: return "SL_RESULT_CONTENT_NOT_FOUND";
            case 11: return "SL_RESULT_PERMISSION_DENIED";
            case 12: return "SL_RESULT_FEATURE_UNSUPPORTED";
            case 13: return "SL_RESULT_INTERNAL_ERROR";
            case 14: return "SL_RESULT_UNKNOWN_ERROR";
            case 15: return "SL_RESULT_OPERATION_ABORTED";
            case 16: return "SL_RESULT_CONTROL_LOST";
            default: return "unknown(" + code + ")";
        }
    }

    // ---- constants ---------------------------------------------------------
    private static final int OUT_SPEAKER = 0;
    private static final int OUT_EARPIECE_WIRED = 1;
    private static final int OUT_BLUETOOTH = 2;

    private static final int ID_SPEAKER = 1001;
    private static final int ID_EARPIECE = 1002;
    private static final int ID_BLUETOOTH = 1003;

    private static final int GAIN_MAX_PERCENT = 400;
    private static final long ROUTE_SETTLE_MS = 300;   // let AudioService apply mode/route first
    private static final long SCO_TIMEOUT_MS = 8000;   // Bluetooth SCO can take several seconds
    private static final long METER_INTERVAL_MS = 80;

    private static final String PREFS = "micbridge";
    private static final String PREF_GAIN = "gain";
    private static final String PREF_OUTPUT = "output";

    // ---- state ---------------------------------------------------------------
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audioManager;
    private SharedPreferences prefs;

    private int outputChoice = OUT_SPEAKER;
    private int lastNonBluetoothChoice = OUT_SPEAKER;
    private int gainPercent = 100;

    private boolean running = false;            // user pressed Start (and not Stop yet)
    private boolean engineInitialized = false;  // native engine currently exists
    private boolean destroyed = false;

    private boolean audioStateSaved = false;
    private int savedAudioMode;
    private boolean savedSpeakerphone;

    private boolean scoRequested = false;
    private boolean scoConnected = false;
    private int lastWiredState = -1;            // -1 unknown, 0 unplugged, 1 plugged
    private boolean suppressOutputCallback = false;
    private String routeNote = null;

    // ---- views ---------------------------------------------------------------
    private Button toggleButton;
    private TextView statusText;
    private TextView gainLabel;
    private SeekBar gainSeek;
    private TextView levelLabel;
    private ProgressBar levelBar;
    private RadioGroup outputGroup;
    private TextView routeText;

    // =========================================================================
    // lifecycle
    // =========================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        gainPercent = Math.max(0, Math.min(GAIN_MAX_PERCENT, prefs.getInt(PREF_GAIN, 100)));
        // Bluetooth is deliberately never restored at launch: it needs a paired,
        // connected headset, so a fresh start always begins on a local output.
        outputChoice = (prefs.getInt(PREF_OUTPUT, OUT_SPEAKER) == OUT_EARPIECE_WIRED)
                ? OUT_EARPIECE_WIRED : OUT_SPEAKER;
        lastNonBluetoothChoice = outputChoice;

        // Hardware volume keys adjust the stream the bridge actually plays on.
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        setContentView(buildUi());

        IntentFilter filter = new IntentFilter();
        filter.addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED);
        filter.addAction(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(routeReceiver, filter);

        if (!nativeLibLoaded) {
            statusText.setText("Native library failed to load: " + nativeLibLoadError);
            toggleButton.setEnabled(false);
            return;
        }
        nativeSetGainPercent(gainPercent);
        statusText.setText("Stopped - press Start.");
        updateRouteText();
        handler.post(meterTick);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        stopBridge();
        try {
            unregisterReceiver(routeReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        super.onDestroy();
    }

    // =========================================================================
    // UI
    // =========================================================================

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTypeface(null, Typeface.BOLD);
        return tv;
    }

    private void addFull(LinearLayout parent, View child, int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMarginDp);
        parent.addView(child, lp);
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Mic \u2192 Speaker Bridge");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        addFull(root, title, 0);

        TextView warning = new TextView(this);
        warning.setText("Use headphones to avoid feedback howling. Voice-communication mode "
                + "with echo cancellation is requested where the device supports it, "
                + "but it is not guaranteed on every device.");
        warning.setTextSize(13);
        warning.setGravity(Gravity.CENTER);
        warning.setAlpha(0.75f);
        addFull(root, warning, 10);

        statusText = new TextView(this);
        statusText.setText("Initializing...");
        statusText.setGravity(Gravity.CENTER);
        statusText.setTextIsSelectable(true); // long-press to copy if it shows an error
        addFull(root, statusText, 14);

        toggleButton = new Button(this);
        toggleButton.setText("Start");
        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!running) {
                    routeNote = null;
                    startBridge();
                } else {
                    stopBridge();
                    statusText.setText("Stopped.");
                }
            }
        });
        addFull(root, toggleButton, 10);

        // ---- gain ----
        gainLabel = sectionLabel("Gain");
        addFull(root, gainLabel, 22);

        gainSeek = new SeekBar(this);
        gainSeek.setMax(GAIN_MAX_PERCENT);
        gainSeek.setProgress(gainPercent);
        gainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                gainPercent = progress;
                updateGainLabel();
                if (nativeLibLoaded) {
                    nativeSetGainPercent(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                prefs.edit().putInt(PREF_GAIN, gainPercent).apply();
            }
        });
        addFull(root, gainSeek, 4);
        updateGainLabel();

        // ---- level meter ----
        levelLabel = new TextView(this);
        levelLabel.setText("Output level");
        levelLabel.setTextSize(13);
        addFull(root, levelLabel, 10);

        levelBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        levelBar.setMax(100);
        addFull(root, levelBar, 2);

        // ---- output choice ----
        addFull(root, sectionLabel("Output"), 22);

        outputGroup = new RadioGroup(this);
        outputGroup.setOrientation(RadioGroup.VERTICAL);
        outputGroup.addView(makeRadio(ID_SPEAKER, "Loudspeaker"));
        outputGroup.addView(makeRadio(ID_EARPIECE, "Earpiece / wired headphones (automatic)"));
        outputGroup.addView(makeRadio(ID_BLUETOOTH, "Bluetooth headset (call audio, mono)"));
        setRadioSelection(outputChoice);
        outputGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (suppressOutputCallback) {
                    return;
                }
                int choice = (checkedId == ID_BLUETOOTH) ? OUT_BLUETOOTH
                        : (checkedId == ID_EARPIECE) ? OUT_EARPIECE_WIRED : OUT_SPEAKER;
                onOutputChosen(choice);
            }
        });
        addFull(root, outputGroup, 4);

        routeText = new TextView(this);
        routeText.setTextSize(13);
        routeText.setAlpha(0.8f);
        addFull(root, routeText, 6);

        return scroll;
    }

    private RadioButton makeRadio(int id, String label) {
        RadioButton rb = new RadioButton(this);
        rb.setId(id);
        rb.setText(label);
        return rb;
    }

    /** Selects a radio button without triggering the change listener. */
    private void setRadioSelection(int choice) {
        suppressOutputCallback = true;
        outputGroup.check(choice == OUT_BLUETOOTH ? ID_BLUETOOTH
                : choice == OUT_EARPIECE_WIRED ? ID_EARPIECE : ID_SPEAKER);
        suppressOutputCallback = false;
    }

    private void updateGainLabel() {
        String db = (gainPercent == 0) ? "muted"
                : String.format(Locale.US, "%+.1f dB", 20.0 * Math.log10(gainPercent / 100.0));
        gainLabel.setText("Gain: " + gainPercent + "%  (" + db + ")"
                + (gainPercent > 250 ? "  - may distort" : ""));
    }

    @SuppressWarnings("deprecation")
    private boolean isWiredHeadsetPlugged() {
        return (lastWiredState >= 0) ? (lastWiredState == 1) : audioManager.isWiredHeadsetOn();
    }

    private void updateRouteText() {
        StringBuilder sb = new StringBuilder();
        switch (outputChoice) {
            case OUT_SPEAKER:
                sb.append("Sound plays from the phone's loudspeaker.");
                break;
            case OUT_EARPIECE_WIRED:
                sb.append(isWiredHeadsetPlugged()
                        ? "Wired headset detected - sound plays through it."
                        : "No wired headset detected - sound plays from the earpiece "
                        + "(hold the phone to your ear).");
                break;
            case OUT_BLUETOOTH:
                if (scoConnected) {
                    sb.append("Bluetooth headset connected. Its microphone is used as the input, too.");
                } else if (scoRequested) {
                    sb.append("Connecting to the Bluetooth headset...");
                } else {
                    sb.append("Connects to a paired Bluetooth headset when you press Start.");
                }
                break;
            default:
                break;
        }
        if (routeNote != null) {
            sb.append("\n").append(routeNote);
        }
        routeText.setText(sb.toString());
    }

    /** Polls the native peak tracker for the on-screen level meter. */
    private final Runnable meterTick = new Runnable() {
        @Override
        public void run() {
            if (destroyed) {
                return;
            }
            try {
                if (engineInitialized) {
                    int peak = nativeGetPeakAndReset();
                    int pct = Math.min(100, (peak * 100) / 32767);
                    levelBar.setProgress(pct);
                    levelLabel.setText(peak >= 32767
                            ? "Output level: CLIPPING - lower the gain"
                            : "Output level: " + pct + "%");
                } else {
                    levelBar.setProgress(0);
                    levelLabel.setText("Output level");
                }
            } catch (Throwable ignored) {
                // never let the meter take the app down
            }
            handler.postDelayed(this, METER_INTERVAL_MS);
        }
    };

    // =========================================================================
    // start / stop / restart
    // =========================================================================

    private boolean hasRecordPermission() {
        return getPackageManager().checkPermission("android.permission.RECORD_AUDIO",
                getPackageName()) == PackageManager.PERMISSION_GRANTED;
    }

    private void startBridge() {
        if (!nativeLibLoaded) {
            return;
        }
        if (!hasRecordPermission()) {
            statusText.setText("RECORD_AUDIO permission is NOT granted.\n"
                    + "Check Settings > Apps > Mic-Speaker Bridge > Permissions.");
            return;
        }
        statusText.setText("Starting...");
        enterCommunicationMode();
        running = true;
        toggleButton.setText("Stop");
        applyRouteThenRun();
    }

    /** Full stop: releases the audio engine and puts the audio mode back. */
    private void stopBridge() {
        handler.removeCallbacks(restartRunnable);
        handler.removeCallbacks(scoTimeout);
        if (engineInitialized) {
            try {
                nativeStop();
                nativeShutdown();
            } catch (Throwable ignored) {
                // shutting down anyway
            }
            engineInitialized = false;
        }
        running = false;
        stopSco();
        leaveCommunicationMode();
        if (!destroyed) {
            toggleButton.setText("Start");
            updateRouteText();
        }
    }

    private final Runnable restartRunnable = new Runnable() {
        @Override
        public void run() {
            restartEngine();
        }
    };

    /** Re-initializes the engine shortly from now (debounced). */
    private void scheduleEngineRestart() {
        handler.removeCallbacks(restartRunnable);
        handler.postDelayed(restartRunnable, ROUTE_SETTLE_MS);
    }

    /**
     * (Re)creates the native engine and starts streaming. Called after any
     * change that can move the microphone or speaker route (output choice,
     * headset plugged/unplugged, Bluetooth connected): the recorder is bound
     * to an input device when it is created, so following a route change with
     * a fresh engine is more reliable than hoping the old one survives it.
     */
    private void restartEngine() {
        if (destroyed || !running) {
            return;
        }
        if (engineInitialized) {
            nativeStop();
            nativeShutdown();
            engineInitialized = false;
        }

        boolean scoMode = (outputChoice == OUT_BLUETOOTH) && scoConnected;
        clearLogcat();
        boolean ok;
        try {
            ok = nativeInit(scoMode ? 1 : 0);
        } catch (Throwable t) {
            stopBridge();
            statusText.setText("nativeInit threw: " + t);
            return;
        }

        if (!ok) {
            int step = nativeGetLastErrorStep();
            int code = nativeGetLastErrorCode();
            int attempted = nativeGetConfigsAttempted();
            String stepName = (step >= 0 && step < STEP_NAMES.length)
                    ? STEP_NAMES[step] : "unknown step " + step;
            String tried = (attempted > 0) ? ("\n(tried " + attempted + " configs)") : "";
            String detail = captureOwnProcessLogcat();
            stopBridge();
            statusText.setText("Failed at: " + stepName + "\n" + slResultName(code)
                    + " (" + code + ")" + tried
                    + "\n\n--- relevant log lines ---\n" + detail);
            return;
        }

        engineInitialized = true;
        nativeStart();
        int rate = nativeGetSelectedSampleRate();
        int ch = nativeGetSelectedChannels();
        statusText.setText("Running - " + rate + " Hz " + (ch == 2 ? "stereo" : "mono")
                + (scoMode ? " (Bluetooth call audio)" : ""));
    }

    // =========================================================================
    // output routing
    // =========================================================================

    private void enterCommunicationMode() {
        if (!audioStateSaved) {
            savedAudioMode = audioManager.getMode();
            savedSpeakerphone = audioManager.isSpeakerphoneOn();
            audioStateSaved = true;
        }
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
    }

    private void leaveCommunicationMode() {
        if (!audioStateSaved) {
            return;
        }
        try {
            audioManager.setSpeakerphoneOn(savedSpeakerphone);
            audioManager.setMode(savedAudioMode);
        } catch (Throwable ignored) {
            // best effort
        }
        audioStateSaved = false;
    }

    private void onOutputChosen(int choice) {
        if (choice == outputChoice) {
            return;
        }
        outputChoice = choice;
        routeNote = null;
        if (choice != OUT_BLUETOOTH) {
            lastNonBluetoothChoice = choice;
            prefs.edit().putInt(PREF_OUTPUT, choice).apply();
        }
        if (running) {
            applyRouteThenRun();
        } else {
            updateRouteText(); // applied when Start is pressed
        }
    }

    /** Applies the chosen route, then (re)starts the engine once it is usable. */
    private void applyRouteThenRun() {
        applyRoute();
        if (!running) {
            return;
        }
        if (outputChoice == OUT_BLUETOOTH && !scoConnected) {
            // The engine is (re)started when the SCO link comes up - see
            // handleScoState() - or we fall back if it never does.
            statusText.setText("Waiting for the Bluetooth headset...");
        } else {
            scheduleEngineRestart();
        }
    }

    private void applyRoute() {
        if (outputChoice == OUT_BLUETOOTH) {
            audioManager.setSpeakerphoneOn(false);
            startSco();
        } else {
            stopSco();
            audioManager.setSpeakerphoneOn(outputChoice == OUT_SPEAKER);
        }
        updateRouteText();
    }

    private void startSco() {
        if (!audioManager.isBluetoothScoAvailableOffCall()) {
            fallBackFromBluetooth("This device does not support Bluetooth call audio outside a call.");
            return;
        }
        scoRequested = true;
        audioManager.startBluetoothSco();
        if (scoConnected) {
            // Already up (another app started it) - route to it right away.
            audioManager.setBluetoothScoOn(true);
        } else {
            handler.removeCallbacks(scoTimeout);
            handler.postDelayed(scoTimeout, SCO_TIMEOUT_MS);
        }
    }

    private void stopSco() {
        handler.removeCallbacks(scoTimeout);
        if (scoRequested) {
            try {
                audioManager.setBluetoothScoOn(false);
                audioManager.stopBluetoothSco();
            } catch (Throwable ignored) {
                // best effort
            }
        }
        scoRequested = false;
    }

    private final Runnable scoTimeout = new Runnable() {
        @Override
        public void run() {
            if (running && outputChoice == OUT_BLUETOOTH && !scoConnected) {
                fallBackFromBluetooth("Couldn't connect to a Bluetooth headset (timed out). "
                        + "Is one paired and connected?");
            }
        }
    };

    /** Bluetooth couldn't be used: go back to the last local output and say why. */
    private void fallBackFromBluetooth(String note) {
        handler.removeCallbacks(scoTimeout);
        stopSco();
        outputChoice = lastNonBluetoothChoice;
        audioManager.setSpeakerphoneOn(outputChoice == OUT_SPEAKER);
        routeNote = note;
        updateRouteText();
        // Updating the radio group from inside its own change callback (this can
        // be reached from one) would re-enter RadioGroup, so defer it.
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!destroyed) {
                    setRadioSelection(outputChoice);
                }
            }
        });
        if (running) {
            scheduleEngineRestart();
        }
    }

    private void handleScoState(int state) {
        switch (state) {
            case AudioManager.SCO_AUDIO_STATE_CONNECTING:
                if (outputChoice == OUT_BLUETOOTH) {
                    updateRouteText();
                }
                break;
            case AudioManager.SCO_AUDIO_STATE_CONNECTED:
                scoConnected = true;
                handler.removeCallbacks(scoTimeout);
                if (running && outputChoice == OUT_BLUETOOTH) {
                    audioManager.setBluetoothScoOn(true);
                    updateRouteText();
                    scheduleEngineRestart();
                } else {
                    updateRouteText();
                }
                break;
            case AudioManager.SCO_AUDIO_STATE_DISCONNECTED:
            case AudioManager.SCO_AUDIO_STATE_ERROR:
            default:
                boolean wasConnected = scoConnected;
                scoConnected = false;
                if (running && outputChoice == OUT_BLUETOOTH && scoRequested) {
                    fallBackFromBluetooth(wasConnected
                            ? "The Bluetooth headset disconnected."
                            : "Couldn't connect to a Bluetooth headset.");
                } else {
                    updateRouteText();
                }
                break;
        }
    }

    private final BroadcastReceiver routeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED.equals(action)) {
                handleScoState(intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE,
                        AudioManager.SCO_AUDIO_STATE_ERROR));
            } else if (Intent.ACTION_HEADSET_PLUG.equals(action)) {
                int state = intent.getIntExtra("state", -1);
                boolean changed = (lastWiredState != -1 && state != lastWiredState);
                lastWiredState = state;
                updateRouteText();
                // Plugging/unplugging moves both the speaker and the mic route,
                // so follow it with a fresh engine (skips the sticky initial broadcast).
                if (changed && running) {
                    scheduleEngineRestart();
                }
            }
        }
    };

    // =========================================================================
    // diagnostics: read our own process's log lines (no adb needed)
    // =========================================================================

    /** Clears the logcat ring buffer so a later capture only contains what
     * happens during our own nativeInit() call. Best-effort. */
    private static void clearLogcat() {
        try {
            java.lang.Process clear = Runtime.getRuntime().exec(new String[]{"logcat", "-c"});
            clear.waitFor();
        } catch (Throwable ignored) {
            // fall through; capture step below will just include more noise
        }
    }

    /**
     * OpenSL ES runs in-process on Android (loaded via dlopen into this app,
     * not a separate system service), so any detailed error it logs internally
     * (via SL_LOGE - the plain SLresult code we get back does NOT carry it) is
     * tagged with our own process id and appears in our own logcat output,
     * which an app can normally read for itself without special permissions.
     */
    private static String captureOwnProcessLogcat() {
        String pidToken = " " + Process.myPid() + " ";
        StringBuilder relevant = new StringBuilder();
        StringBuilder allLines = new StringBuilder();
        int totalLines = 0;
        try {
            java.lang.Process p =
                    Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-v", "threadtime"});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                totalLines++;
                allLines.append(line).append('\n');
                if (line.contains(pidToken)) {
                    relevant.append(line).append('\n');
                }
            }
            p.waitFor();
        } catch (Throwable t) {
            return "logcat capture failed: " + t;
        }
        if (relevant.length() > 0) {
            String s = relevant.toString();
            return s.length() > 4000 ? ("...\n" + s.substring(s.length() - 4000)) : s;
        }
        String s = allLines.toString();
        if (s.isEmpty()) {
            return "(no logcat output captured - " + totalLines + " lines read)";
        }
        return "(no lines matched our pid " + Process.myPid() + "; showing log tail)\n"
                + (s.length() > 3000 ? s.substring(s.length() - 3000) : s);
    }
}
