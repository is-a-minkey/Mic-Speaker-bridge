from PIL import Image, ImageDraw

SIZE = 432
img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

bg = (17, 78, 84, 255)          # deep teal
fg = (255, 255, 255, 255)       # white
wave = (255, 255, 255, 190)     # soft white

# rounded-square background
radius = int(SIZE * 0.22)
draw.rounded_rectangle([0, 0, SIZE - 1, SIZE - 1], radius=radius, fill=bg)

# --- microphone ---
cx = SIZE * 0.36
mic_w = SIZE * 0.17
head_top = SIZE * 0.22
head_h = SIZE * 0.28
head_bottom = head_top + head_h
draw.rounded_rectangle([cx - mic_w / 2, head_top, cx + mic_w / 2, head_bottom],
                        radius=mic_w / 2, fill=fg)

lw = max(3, int(SIZE * 0.024))
stand_r = mic_w * 0.95
stand_cy = head_bottom - mic_w * 0.10
draw.arc([cx - stand_r, stand_cy - stand_r, cx + stand_r, stand_cy + stand_r],
          start=15, end=165, fill=fg, width=lw)

pole_top = stand_cy + stand_r * 0.65
pole_bottom = pole_top + SIZE * 0.085
draw.line([cx, pole_top, cx, pole_bottom], fill=fg, width=lw)
base_w = SIZE * 0.15
draw.line([cx - base_w / 2, pole_bottom, cx + base_w / 2, pole_bottom], fill=fg, width=lw)

# --- soundwave arcs (mic -> speaker transmission) ---
wave_cx = cx + mic_w * 0.55
wave_cy = head_top + head_h / 2
wlw = max(3, int(SIZE * 0.021))
for r in (SIZE * 0.135, SIZE * 0.195, SIZE * 0.255):
    bbox = [wave_cx - r, wave_cy - r, wave_cx + r, wave_cy + r]
    draw.arc(bbox, start=-38, end=38, fill=wave, width=wlw)

img.save("/home/claude/project/icon_gen/master.png")
print("saved master icon:", img.size)
