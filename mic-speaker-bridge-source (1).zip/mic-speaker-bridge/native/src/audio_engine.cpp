/*
 * Mic -> speaker low-latency loopback using OpenSL ES.
 *
 * Design notes:
 *  - libOpenSLES.so is opened with dlopen() and every entry point (the
 *    slCreateEngine() function plus every SL_IID_* interface-id constant)
 *    is resolved with dlsym() at runtime, so the *build* never needs the
 *    NDK's compile-time stub library for OpenSL ES.
 *
 *  - No heap allocation, no exceptions, no RTTI, no libc++ needed: buffers
 *    are fixed-size static (.bss) arrays. External dependencies are just
 *    memset (libc), dlopen/dlsym (libdl) and __android_log_print (liblog),
 *    plus the ARM32 __aeabi_mem* helpers the compiler emits on its own.
 *
 *  - Every OpenSL ES call's SLresult is checked, and every GetInterface()
 *    output pointer is verified non-null, before use. On failure, both a
 *    *step id* (which call failed) and the raw SLresult are recorded in
 *    g_lastErrorStep/g_lastErrorCode - retrievable from Java as plain ints,
 *    which MainActivity shows on screen (no adb needed).
 *
 *  - The recorder is created *and realized* inside the format sweep: on
 *    real hardware the recorder's parameters are only fully validated at
 *    Realize() time (that is when the underlying AudioRecord is opened), so
 *    a candidate is only accepted once Realize() has succeeded too. This is
 *    what lets the same code cope with, e.g., a Bluetooth SCO input that
 *    only offers 8/16 kHz mono.
 *
 *  - Gain: applied per sample in the recorder callback with integer Q8
 *    fixed-point math and saturation (no float, no division). The same loop
 *    tracks the peak level for the UI meter.
 *
 *  - Threading model: only the *recorder* buffer-queue callback touches the
 *    audio buffers, and OpenSL ES serializes calls to a given callback, so
 *    no locking is needed. g_running / g_gainQ8 / g_peakAccum are plain
 *    volatile ints written from the JNI thread and read from the audio
 *    thread - the standard low-overhead pattern for real-time audio, where
 *    a stale value for one 20 ms buffer is harmless.
 */

#include <dlfcn.h>
#include <stdint.h>

#include "SLES/OpenSLES.h"
#include "SLES/OpenSLES_Android.h"
#include "SLES/OpenSLES_AndroidConfiguration.h"
#include "audio_engine.h"

extern "C" void *memset(void *dst, int c, unsigned long n);
extern "C" int __android_log_print(int prio, const char *tag, const char *fmt, ...);

#define LOG_TAG "AudioBridge"
#define ANDROID_LOG_INFO 4
#define ANDROID_LOG_WARN 5
#define ANDROID_LOG_ERROR 6
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Step ids - keep in sync with MainActivity.STEP_NAMES (index-for-index).
enum InitStep {
    STEP_NONE = 0,
    STEP_DLOPEN_LIBOPENSLES = 1,
    STEP_DLSYM_SLCREATEENGINE = 2,
    STEP_RESOLVE_REQUIRED_IIDS = 3,
    STEP_SLCREATEENGINE = 4,
    STEP_REALIZE_ENGINE = 5,
    STEP_GET_ENGINE_INTERFACE = 6,
    STEP_CREATE_OUTPUT_MIX = 7,
    STEP_REALIZE_OUTPUT_MIX = 8,
    STEP_CREATE_AUDIO_RECORDER = 9,
    STEP_REALIZE_RECORDER = 10,
    STEP_GET_RECORD_INTERFACE = 11,
    STEP_GET_RECORD_BUFFERQUEUE_INTERFACE = 12,
    STEP_REGISTER_RECORD_CALLBACK = 13,
    STEP_CREATE_AUDIO_PLAYER = 14,
    STEP_REALIZE_PLAYER = 15,
    STEP_GET_PLAY_INTERFACE = 16,
    STEP_GET_PLAY_BUFFERQUEUE_INTERFACE = 17,
    STEP_COUNT = 18
};

// A recorder format to try. Real OEM audio HALs can be pickier than the AOSP
// reference implementation, so instead of betting on one hardcoded format,
// audiobridge_init() walks a list against the actual device. All rates are
// ones Android's OpenSL ES documentation lists as supported for recording.
// SL_SPEAKER_FRONT_LEFT is the mask Android expects for a single channel
// (see AOSP frameworks/wilhelm/src/android/channels.cpp); a mask of 0
// ("unspecified") is kept as a last-resort fallback.
struct FormatCandidate {
    int sampleRateHz;
    int numChannels;      // 1 (mono) or 2 (stereo)
    SLuint32 channelMask;
};

// Normal operation: prefer CD-ish rates, then voice rates.
static const FormatCandidate kFormatCandidates[] = {
    {44100, 1, SL_SPEAKER_FRONT_LEFT},
    {44100, 2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {16000, 1, SL_SPEAKER_FRONT_LEFT},
    {16000, 2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {8000,  1, SL_SPEAKER_FRONT_LEFT},
    {8000,  2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {48000, 1, SL_SPEAKER_FRONT_LEFT},
    {48000, 2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {22050, 1, SL_SPEAKER_FRONT_LEFT},
    {22050, 2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {11025, 1, SL_SPEAKER_FRONT_LEFT},
    {11025, 2, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT},
    {44100, 1, 0},
    {44100, 2, 0},
    {16000, 1, 0},
    {16000, 2, 0},
    {8000,  1, 0},
    {8000,  2, 0},
};
constexpr int kNumFormatCandidates = sizeof(kFormatCandidates) / sizeof(kFormatCandidates[0]);

// Bluetooth SCO (call audio): Android documents that streams routed to a SCO
// headset must be mono at 8 kHz or 16 kHz (input: 8 kHz on older releases).
static const FormatCandidate kScoCandidates[] = {
    {8000,  1, SL_SPEAKER_FRONT_LEFT},
    {16000, 1, SL_SPEAKER_FRONT_LEFT},
    {8000,  1, 0},
    {16000, 1, 0},
};
constexpr int kNumScoCandidates = sizeof(kScoCandidates) / sizeof(kScoCandidates[0]);

namespace {

// 8 buffers rather than 4: slack against scheduling jitter on older devices.
// Audio is forwarded the moment each buffer completes, so this buys underrun
// tolerance without adding steady-state latency.
constexpr int kNumBuffers = 8;
constexpr int kMaxBufferBytes = 8192;              // generous cap; ~3.8 KB is the real max
constexpr int kMaxBufferSamples = kMaxBufferBytes / 2;
constexpr int kPrerollBuffers = 2;                 // silent buffers queued before playback starts
constexpr int kBufferMs = 20;

typedef SLresult(SLAPIENTRY *slCreateEngine_t)(SLObjectItf *, SLuint32,
                                                const SLEngineOption *, SLuint32,
                                                const SLInterfaceID *, const SLboolean *);

// ---- runtime-resolved OpenSL ES entry points -------------------------------
void *g_slHandle = nullptr;
slCreateEngine_t g_slCreateEngine = nullptr;
SLInterfaceID g_iidEngine = nullptr;
SLInterfaceID g_iidRecord = nullptr;
SLInterfaceID g_iidPlay = nullptr;
SLInterfaceID g_iidBufferQueue = nullptr;
SLInterfaceID g_iidAndroidConfig = nullptr; // optional
SLInterfaceID g_iidAEC = nullptr;           // optional (newer Android only)

// ---- OpenSL ES object graph -------------------------------------------------
SLObjectItf g_engineObj = nullptr;
SLEngineItf g_engine = nullptr;
SLObjectItf g_outputMixObj = nullptr;
SLObjectItf g_recorderObj = nullptr;
SLRecordItf g_recordItf = nullptr;
SLAndroidSimpleBufferQueueItf g_recBufQ = nullptr;
SLObjectItf g_playerObj = nullptr;
SLPlayItf g_playItf = nullptr;
SLAndroidSimpleBufferQueueItf g_playBufQ = nullptr;

// ---- audio buffers (static, no heap) ---------------------------------------
// int16_t (not raw bytes) so the gain loop reads/writes them with their real
// type - no aliasing tricks, and alignas keeps SIMD-friendly alignment.
alignas(16) int16_t g_recBuf[kNumBuffers][kMaxBufferSamples];
alignas(16) int16_t g_playBuf[kNumBuffers][kMaxBufferSamples];
int g_bufferBytes = 0;
int g_recIdx = 0;
int g_playIdx = 0;
volatile bool g_running = false;
bool g_initialized = false;

// ---- gain / level ------------------------------------------------------------
volatile int g_gainQ8 = 256;   // 256 == 1.0x
volatile int g_peakAccum = 0;  // max |sample| sent to the speaker since last read

// ---- diagnostics -------------------------------------------------------------
int g_lastErrorStep = STEP_NONE;
int g_lastErrorCode = -1;
int g_configsAttempted = 0;
int g_selectedSampleRateHz = 0;
int g_selectedNumChannels = 1;
SLuint32 g_selectedChannelMask = SL_SPEAKER_FRONT_LEFT;

// Destroys whatever OpenSL ES objects currently exist (children first) and
// clears every pointer into them. Safe on a partially built graph.
void TeardownObjects() {
    if (g_playerObj) (*g_playerObj)->Destroy(g_playerObj);
    if (g_recorderObj) (*g_recorderObj)->Destroy(g_recorderObj);
    if (g_outputMixObj) (*g_outputMixObj)->Destroy(g_outputMixObj);
    if (g_engineObj) (*g_engineObj)->Destroy(g_engineObj);
    g_playerObj = nullptr;
    g_recorderObj = nullptr;
    g_outputMixObj = nullptr;
    g_engineObj = nullptr;
    g_engine = nullptr;
    g_recordItf = nullptr;
    g_recBufQ = nullptr;
    g_playItf = nullptr;
    g_playBufQ = nullptr;
}

SLInterfaceID ResolveIID(const char *symbolName, bool required) {
    void *addr = dlsym(g_slHandle, symbolName);
    if (!addr) {
        if (required) LOGE("dlsym failed for required symbol %s", symbolName);
        else LOGW("optional symbol %s not available on this device", symbolName);
        return nullptr;
    }
    // These symbols ARE the SLInterfaceID value itself (a global of type
    // "const struct SLInterfaceID_ *"), so dlsym gives us the address of
    // that pointer-sized global; dereference once to get the value.
    return *reinterpret_cast<SLInterfaceID *>(addr);
}

void RecorderCallback(SLAndroidSimpleBufferQueueItf bq, void * /*context*/) {
    if (!g_running) {
        return;
    }

    // Copy the just-filled mic buffer into a playback buffer while applying
    // gain (Q8 fixed point, saturating) and tracking the peak for the meter.
    const int gain = g_gainQ8;
    const int16_t *src = g_recBuf[g_recIdx];
    int16_t *dst = g_playBuf[g_playIdx];
    const int n = g_bufferBytes >> 1;
    int peak = 0;
    for (int i = 0; i < n; i++) {
        int32_t v = ((int32_t) src[i] * gain) >> 8;
        if (v > 32767) v = 32767;
        else if (v < -32768) v = -32768;
        dst[i] = (int16_t) v;
        const int32_t a = (v < 0) ? -v : v;
        if (a > peak) peak = a;
    }
    if (peak > g_peakAccum) g_peakAccum = peak;

    (*g_playBufQ)->Enqueue(g_playBufQ, dst, (SLuint32) g_bufferBytes);
    g_playIdx = (g_playIdx + 1) % kNumBuffers;

    // The mic buffer's data has been copied out, so hand it straight back.
    (*bq)->Enqueue(bq, g_recBuf[g_recIdx], (SLuint32) g_bufferBytes);
    g_recIdx = (g_recIdx + 1) % kNumBuffers;
}

bool GetRequiredInterface(SLObjectItf obj, SLInterfaceID iid, void *out) {
    if (!iid) return false;
    SLresult r = (*obj)->GetInterface(obj, iid, out);
    return r == SL_RESULT_SUCCESS && *reinterpret_cast<void **>(out) != nullptr;
}

} // namespace

#define REQUIRE(cond, step, msg)                                                      \
    do {                                                                              \
        if (!(cond)) {                                                                \
            g_lastErrorStep = (step);                                                 \
            g_lastErrorCode = -1;                                                     \
            LOGE("init failed at step %d: %s", (int) (step), msg);                    \
            TeardownObjects();                                                        \
            return 0;                                                                 \
        }                                                                             \
    } while (0)

#define REQUIRE_OK(result, step, msg)                                                 \
    do {                                                                              \
        SLresult _r = (result);                                                       \
        if (_r != SL_RESULT_SUCCESS) {                                                \
            g_lastErrorStep = (step);                                                 \
            g_lastErrorCode = (int) _r;                                               \
            LOGE("init failed at step %d: %s (SLresult=%u)", (int) (step), msg,       \
                 (unsigned) _r);                                                      \
            TeardownObjects();                                                        \
            return 0;                                                                 \
        }                                                                             \
    } while (0)

extern "C" int audiobridge_get_last_error_step(void) { return g_lastErrorStep; }
extern "C" int audiobridge_get_last_error_code(void) { return g_lastErrorCode; }
extern "C" int audiobridge_get_configs_attempted(void) { return g_configsAttempted; }
extern "C" int audiobridge_get_selected_sample_rate(void) { return g_selectedSampleRateHz; }
extern "C" int audiobridge_get_selected_channels(void) { return g_selectedNumChannels; }

extern "C" void audiobridge_set_gain_percent(int percent) {
    if (percent < 0) percent = 0;
    if (percent > 1000) percent = 1000; // cap keeps sample*gain inside int32 (32768*2560)
    g_gainQ8 = (percent * 256) / 100;
}

extern "C" int audiobridge_get_peak_and_reset(void) {
    const int p = g_peakAccum;
    g_peakAccum = 0;
    return p;
}

extern "C" int audiobridge_init(int scoMode) {
    if (g_initialized) {
        return 1;
    }
    g_lastErrorStep = STEP_NONE;
    g_lastErrorCode = -1;
    g_configsAttempted = 0;
    g_selectedSampleRateHz = 0;
    g_selectedNumChannels = 1;
    g_selectedChannelMask = SL_SPEAKER_FRONT_LEFT;
    g_peakAccum = 0;

    g_slHandle = dlopen("libOpenSLES.so", RTLD_NOW);
    REQUIRE(g_slHandle != nullptr, STEP_DLOPEN_LIBOPENSLES, "dlopen(libOpenSLES.so)");

    g_slCreateEngine = reinterpret_cast<slCreateEngine_t>(dlsym(g_slHandle, "slCreateEngine"));
    REQUIRE(g_slCreateEngine != nullptr, STEP_DLSYM_SLCREATEENGINE, "dlsym(slCreateEngine)");

    g_iidEngine = ResolveIID("SL_IID_ENGINE", true);
    g_iidRecord = ResolveIID("SL_IID_RECORD", true);
    g_iidPlay = ResolveIID("SL_IID_PLAY", true);
    g_iidBufferQueue = ResolveIID("SL_IID_ANDROIDSIMPLEBUFFERQUEUE", true);
    g_iidAndroidConfig = ResolveIID("SL_IID_ANDROIDCONFIGURATION", false);   // optional
    g_iidAEC = ResolveIID("SL_IID_ANDROIDACOUSTICECHOCANCELLATION", false); // optional
    REQUIRE(g_iidEngine && g_iidRecord && g_iidPlay && g_iidBufferQueue,
            STEP_RESOLVE_REQUIRED_IIDS, "required IID resolution");

    SLresult r;

    // ---- Engine ----
    r = g_slCreateEngine(&g_engineObj, 0, nullptr, 0, nullptr, nullptr);
    REQUIRE_OK(r, STEP_SLCREATEENGINE, "slCreateEngine");
    r = (*g_engineObj)->Realize(g_engineObj, SL_BOOLEAN_FALSE);
    REQUIRE_OK(r, STEP_REALIZE_ENGINE, "Realize(engine)");
    REQUIRE(GetRequiredInterface(g_engineObj, g_iidEngine, &g_engine),
            STEP_GET_ENGINE_INTERFACE, "GetInterface(SL_IID_ENGINE)");

    // ---- Output mix ----
    r = (*g_engine)->CreateOutputMix(g_engine, &g_outputMixObj, 0, nullptr, nullptr);
    REQUIRE_OK(r, STEP_CREATE_OUTPUT_MIX, "CreateOutputMix");
    r = (*g_outputMixObj)->Realize(g_outputMixObj, SL_BOOLEAN_FALSE);
    REQUIRE_OK(r, STEP_REALIZE_OUTPUT_MIX, "Realize(outputMix)");

    // ---- Audio recorder (mic) ----
    bool recorderAec = false;
    {
        SLDataLocator_IODevice locDev = {SL_DATALOCATOR_IODEVICE, SL_IODEVICE_AUDIOINPUT,
                                          SL_DEFAULTDEVICEID_AUDIOINPUT, nullptr};
        SLDataSource audioSrc = {&locDev, nullptr};
        SLDataLocator_AndroidSimpleBufferQueue locBq = {
            SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, (SLuint32) kNumBuffers};

        const FormatCandidate *cands = scoMode ? kScoCandidates : kFormatCandidates;
        const int numCands = scoMode ? kNumScoCandidates : kNumFormatCandidates;

        bool ready = false;
        SLresult lastResult = SL_RESULT_SUCCESS;
        int lastStep = STEP_CREATE_AUDIO_RECORDER;

        for (int i = 0; i < numCands && !ready; i++) {
            g_configsAttempted++;
            SLDataFormat_PCM formatPcm = {
                SL_DATAFORMAT_PCM, (SLuint32) cands[i].numChannels,
                (SLuint32) cands[i].sampleRateHz * 1000,
                SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                cands[i].channelMask, SL_BYTEORDER_LITTLEENDIAN};
            SLDataSink audioSnk = {&locBq, &formatPcm};

            // Interface requests, richest first. The two optional interfaces
            // (Android configuration -> voice-communication preset; echo
            // canceller, newer Android only) are dropped step by step if the
            // device rejects the richer request, so a device that dislikes
            // them still gets a working plain recorder.
            for (int level = 0; level < 3 && !ready; level++) {
                if (level == 1 && !g_iidAEC) continue;            // identical to level 0
                if (level == 2 && !g_iidAndroidConfig) continue;  // identical to previous
                const bool wantConfig = g_iidAndroidConfig && level <= 1;
                const bool wantAec = g_iidAEC && level == 0;

                SLInterfaceID ids[3];
                SLboolean req[3];
                SLuint32 numIds = 0;
                ids[numIds] = g_iidBufferQueue; req[numIds++] = SL_BOOLEAN_TRUE;
                if (wantConfig) { ids[numIds] = g_iidAndroidConfig; req[numIds++] = SL_BOOLEAN_FALSE; }
                if (wantAec) { ids[numIds] = g_iidAEC; req[numIds++] = SL_BOOLEAN_FALSE; }

                lastResult = (*g_engine)->CreateAudioRecorder(g_engine, &g_recorderObj, &audioSrc,
                                                               &audioSnk, numIds, ids, req);
                if (lastResult != SL_RESULT_SUCCESS) {
                    lastStep = STEP_CREATE_AUDIO_RECORDER;
                    LOGW("CreateAudioRecorder rejected %d Hz/%dch/mask=0x%x (ifaces=%u): SLresult=%u",
                         cands[i].sampleRateHz, cands[i].numChannels,
                         (unsigned) cands[i].channelMask, (unsigned) numIds, (unsigned) lastResult);
                    g_recorderObj = nullptr;
                    continue;
                }

                // The preset must be set while the object is still unrealized.
                if (wantConfig) {
                    SLAndroidConfigurationItf recConfig = nullptr;
                    if ((*g_recorderObj)->GetInterface(g_recorderObj, g_iidAndroidConfig,
                                                       &recConfig) == SL_RESULT_SUCCESS && recConfig) {
                        SLuint32 preset = SL_ANDROID_RECORDING_PRESET_VOICE_COMMUNICATION;
                        SLresult pr = (*recConfig)->SetConfiguration(
                            recConfig, SL_ANDROID_KEY_RECORDING_PRESET, &preset, sizeof(preset));
                        if (pr != SL_RESULT_SUCCESS) {
                            LOGW("voice-communication preset not accepted (%u)", (unsigned) pr);
                        }
                    }
                }

                lastResult = (*g_recorderObj)->Realize(g_recorderObj, SL_BOOLEAN_FALSE);
                if (lastResult != SL_RESULT_SUCCESS) {
                    lastStep = STEP_REALIZE_RECORDER;
                    LOGW("Realize(recorder) rejected %d Hz/%dch/mask=0x%x (ifaces=%u): SLresult=%u",
                         cands[i].sampleRateHz, cands[i].numChannels,
                         (unsigned) cands[i].channelMask, (unsigned) numIds, (unsigned) lastResult);
                    (*g_recorderObj)->Destroy(g_recorderObj);
                    g_recorderObj = nullptr;
                    continue;
                }

                ready = true;
                recorderAec = wantAec;
                g_selectedSampleRateHz = cands[i].sampleRateHz;
                g_selectedNumChannels = cands[i].numChannels;
                g_selectedChannelMask = cands[i].channelMask;
                LOGI("recorder ready: candidate #%d = %d Hz, %dch, mask=0x%x, config=%d aec=%d",
                     i, cands[i].sampleRateHz, cands[i].numChannels,
                     (unsigned) cands[i].channelMask, wantConfig ? 1 : 0, wantAec ? 1 : 0);
            }
        }

        if (!ready) {
            g_lastErrorStep = lastStep;
            g_lastErrorCode = (int) lastResult;
            LOGE("init failed at step %d: no recorder format accepted (last SLresult=%u, %d tried)",
                 lastStep, (unsigned) lastResult, g_configsAttempted);
            TeardownObjects();
            return 0;
        }

        // kBufferMs of audio at whichever rate/channel-count the device accepted.
        g_bufferBytes = (g_selectedSampleRateHz * kBufferMs / 1000) * g_selectedNumChannels * 2;
        if (g_bufferBytes <= 0 || g_bufferBytes > kMaxBufferBytes) {
            g_bufferBytes = (g_bufferBytes <= 0) ? 512 : kMaxBufferBytes;
        }

        REQUIRE(GetRequiredInterface(g_recorderObj, g_iidRecord, &g_recordItf),
                STEP_GET_RECORD_INTERFACE, "GetInterface(SL_IID_RECORD)");
        REQUIRE(GetRequiredInterface(g_recorderObj, g_iidBufferQueue, &g_recBufQ),
                STEP_GET_RECORD_BUFFERQUEUE_INTERFACE, "GetInterface(bufferqueue,rec)");

        r = (*g_recBufQ)->RegisterCallback(g_recBufQ, RecorderCallback, nullptr);
        REQUIRE_OK(r, STEP_REGISTER_RECORD_CALLBACK, "RegisterCallback(recorder)");

        if (recorderAec) {
            SLAndroidAcousticEchoCancellationItf aec = nullptr;
            if ((*g_recorderObj)->GetInterface(g_recorderObj, g_iidAEC, &aec) == SL_RESULT_SUCCESS &&
                    aec) {
                (*aec)->SetEnabled(aec, SL_BOOLEAN_TRUE);
                LOGI("acoustic echo canceller enabled");
            }
        }
    }

    // ---- Audio player (speaker / earpiece / headset - chosen by the OS route) ----
    {
        SLDataLocator_AndroidSimpleBufferQueue locBq = {
            SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, (SLuint32) kNumBuffers};
        // Must match what the recorder settled on (rate, channel count, mask):
        // this project copies raw PCM straight through with no resampling or
        // remixing, so any mismatch would play at the wrong pitch/speed.
        SLDataFormat_PCM formatPcm = {
            SL_DATAFORMAT_PCM, (SLuint32) g_selectedNumChannels,
            (SLuint32) g_selectedSampleRateHz * 1000, SL_PCMSAMPLEFORMAT_FIXED_16,
            SL_PCMSAMPLEFORMAT_FIXED_16, g_selectedChannelMask, SL_BYTEORDER_LITTLEENDIAN};
        SLDataSource audioSrc = {&locBq, &formatPcm};

        SLDataLocator_OutputMix locOutmix = {SL_DATALOCATOR_OUTPUTMIX, g_outputMixObj};
        SLDataSink audioSnk = {&locOutmix, nullptr};

        bool ready = false;
        SLresult lastResult = SL_RESULT_SUCCESS;
        int lastStep = STEP_CREATE_AUDIO_PLAYER;

        for (int level = 0; level < 2 && !ready; level++) {
            if (level == 1 && !g_iidAndroidConfig) continue; // identical to level 0
            const bool wantConfig = g_iidAndroidConfig && level == 0;

            SLInterfaceID ids[2];
            SLboolean req[2];
            SLuint32 numIds = 0;
            ids[numIds] = g_iidBufferQueue; req[numIds++] = SL_BOOLEAN_TRUE;
            if (wantConfig) { ids[numIds] = g_iidAndroidConfig; req[numIds++] = SL_BOOLEAN_FALSE; }

            lastResult = (*g_engine)->CreateAudioPlayer(g_engine, &g_playerObj, &audioSrc,
                                                         &audioSnk, numIds, ids, req);
            if (lastResult != SL_RESULT_SUCCESS) {
                lastStep = STEP_CREATE_AUDIO_PLAYER;
                LOGW("CreateAudioPlayer failed (ifaces=%u): SLresult=%u", (unsigned) numIds,
                     (unsigned) lastResult);
                g_playerObj = nullptr;
                continue;
            }

            // STREAM_VOICE_CALL is what lets the app steer this stream to the
            // earpiece / loudspeaker / Bluetooth SCO via AudioManager (and is
            // the only stream type Android routes to a SCO headset).
            if (wantConfig) {
                SLAndroidConfigurationItf playConfig = nullptr;
                if ((*g_playerObj)->GetInterface(g_playerObj, g_iidAndroidConfig,
                                                 &playConfig) == SL_RESULT_SUCCESS && playConfig) {
                    SLint32 streamType = SL_ANDROID_STREAM_VOICE;
                    SLresult sr = (*playConfig)->SetConfiguration(
                        playConfig, SL_ANDROID_KEY_STREAM_TYPE, &streamType, sizeof(streamType));
                    if (sr != SL_RESULT_SUCCESS) {
                        LOGW("voice stream type not accepted (%u)", (unsigned) sr);
                    }
                }
            }

            lastResult = (*g_playerObj)->Realize(g_playerObj, SL_BOOLEAN_FALSE);
            if (lastResult != SL_RESULT_SUCCESS) {
                lastStep = STEP_REALIZE_PLAYER;
                LOGW("Realize(player) failed (ifaces=%u): SLresult=%u", (unsigned) numIds,
                     (unsigned) lastResult);
                (*g_playerObj)->Destroy(g_playerObj);
                g_playerObj = nullptr;
                continue;
            }
            ready = true;
        }

        if (!ready) {
            g_lastErrorStep = lastStep;
            g_lastErrorCode = (int) lastResult;
            LOGE("init failed at step %d: player not created (last SLresult=%u)", lastStep,
                 (unsigned) lastResult);
            TeardownObjects();
            return 0;
        }

        REQUIRE(GetRequiredInterface(g_playerObj, g_iidPlay, &g_playItf),
                STEP_GET_PLAY_INTERFACE, "GetInterface(SL_IID_PLAY)");
        REQUIRE(GetRequiredInterface(g_playerObj, g_iidBufferQueue, &g_playBufQ),
                STEP_GET_PLAY_BUFFERQUEUE_INTERFACE, "GetInterface(bufferqueue,play)");
    }

    g_initialized = true;
    LOGI("init OK: %d Hz, %dch, bufferBytes=%d, candidatesTried=%d, scoMode=%d",
         g_selectedSampleRateHz, g_selectedNumChannels, g_bufferBytes, g_configsAttempted,
         scoMode ? 1 : 0);
    return 1;
}

extern "C" void audiobridge_start(void) {
    if (!g_initialized || g_running) return;

    memset(g_recBuf, 0, sizeof(g_recBuf));
    memset(g_playBuf, 0, sizeof(g_playBuf));
    g_recIdx = 0;
    g_peakAccum = 0;
    g_running = true;

    // Give the player a couple of (already-zeroed) buffers before it goes to
    // PLAYING, so it is never left with an empty queue while waiting for the
    // first real recorder callback - an empty-queue gap at startup is a
    // common source of an audible click/glitch. g_playIdx starts past these
    // pre-rolled slots so the first real writes land on fresh buffers.
    for (int i = 0; i < kPrerollBuffers; i++) {
        (*g_playBufQ)->Enqueue(g_playBufQ, g_playBuf[i], (SLuint32) g_bufferBytes);
    }
    g_playIdx = kPrerollBuffers % kNumBuffers;

    (*g_playItf)->SetPlayState(g_playItf, SL_PLAYSTATE_PLAYING);

    // Prime the recorder queue: it only starts filling buffers we've enqueued.
    for (int i = 0; i < kNumBuffers; i++) {
        (*g_recBufQ)->Enqueue(g_recBufQ, g_recBuf[i], (SLuint32) g_bufferBytes);
    }
    (*g_recordItf)->SetRecordState(g_recordItf, SL_RECORDSTATE_RECORDING);
    LOGI("started");
}

extern "C" void audiobridge_stop(void) {
    if (!g_initialized || !g_running) return;
    g_running = false;
    (*g_recordItf)->SetRecordState(g_recordItf, SL_RECORDSTATE_STOPPED);
    (*g_playItf)->SetPlayState(g_playItf, SL_PLAYSTATE_STOPPED);
    (*g_recBufQ)->Clear(g_recBufQ);
    (*g_playBufQ)->Clear(g_playBufQ);
    LOGI("stopped");
}

extern "C" void audiobridge_shutdown(void) {
    audiobridge_stop();          // no-op unless running
    TeardownObjects();           // no-op on an empty graph
    g_initialized = false;
    LOGI("shutdown complete");
}
