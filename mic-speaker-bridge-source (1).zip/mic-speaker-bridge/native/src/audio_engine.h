#ifndef AUDIOBRIDGE_AUDIO_ENGINE_H
#define AUDIOBRIDGE_AUDIO_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/* One-time setup of the OpenSL ES engine, recorder and player.
 *
 * scoMode != 0 restricts the recorder to mono 16 kHz / 8 kHz, which is all a
 * Bluetooth SCO (call-audio) headset can deliver. Otherwise a wider list of
 * rates/channel layouts is tried against the real device and the first one
 * that both CreateAudioRecorder() *and* Realize() accept is used.
 * Returns 1 on success, 0 on failure (see the diagnostics getters below). */
int audiobridge_init(int scoMode);

/* Begin mic -> speaker passthrough. */
void audiobridge_start(void);

/* Stop passthrough (engine stays initialized; start() can be called again). */
void audiobridge_stop(void);

/* Tear everything down. Safe to call at any time, including after a failed
 * init, and safe to follow with another audiobridge_init(). */
void audiobridge_shutdown(void);

/* Software gain applied to every sample between mic and speaker, in percent
 * (100 = unchanged). Integer fixed-point on purpose: passing floats through
 * JNI on 32-bit ARM depends on the float calling convention (softfp vs
 * hard-float), which is exactly the kind of ABI mismatch this project avoids
 * by using ints. Safe to call at any time, including before init. */
void audiobridge_set_gain_percent(int percent);

/* Largest absolute sample value (0..32768) that went to the speaker since
 * the previous call; resets the tracker. Drives the on-screen level meter. */
int audiobridge_get_peak_and_reset(void);

/* Diagnostics for when audiobridge_init() returns 0. Deliberately plain
 * ints (not strings) - returning a jstring would require implementing
 * several JNIEnv methods we otherwise never need. Java maps the step id
 * to a readable name and the code to an SL_RESULT_* name; see
 * MainActivity's STEP_NAMES/slResultName(). */
int audiobridge_get_last_error_step(void);
int audiobridge_get_last_error_code(void); /* SLresult, or -1 if not applicable */

/* How many (sampleRate, channels, channelMask) candidates the recorder sweep
 * tried, and which format it settled on - 0 if none worked yet. */
int audiobridge_get_configs_attempted(void);
int audiobridge_get_selected_sample_rate(void);
int audiobridge_get_selected_channels(void);

#ifdef __cplusplus
}
#endif

#endif /* AUDIOBRIDGE_AUDIO_ENGINE_H */
