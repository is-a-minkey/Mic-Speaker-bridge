#include "jni.h"
#include "audio_engine.h"

// Every function here takes and returns only primitives (jint / jboolean /
// void), so no JNIEnv method is ever called - see the note in jni.h. Names must
// match MainActivity's `native` declarations exactly; build.sh's verification
// step checks that every Java native method has an export here.

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_miclink_MainActivity_nativeInit(JNIEnv *, jclass, jint scoMode) {
    return audiobridge_init((int) scoMode) ? 1 : 0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_miclink_MainActivity_nativeStart(JNIEnv *, jclass) {
    audiobridge_start();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_miclink_MainActivity_nativeStop(JNIEnv *, jclass) {
    audiobridge_stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_miclink_MainActivity_nativeShutdown(JNIEnv *, jclass) {
    audiobridge_shutdown();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_miclink_MainActivity_nativeSetGainPercent(JNIEnv *, jclass, jint percent) {
    audiobridge_set_gain_percent((int) percent);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetPeakAndReset(JNIEnv *, jclass) {
    return (jint) audiobridge_get_peak_and_reset();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetLastErrorStep(JNIEnv *, jclass) {
    return (jint) audiobridge_get_last_error_step();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetLastErrorCode(JNIEnv *, jclass) {
    return (jint) audiobridge_get_last_error_code();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetConfigsAttempted(JNIEnv *, jclass) {
    return (jint) audiobridge_get_configs_attempted();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetSelectedSampleRate(JNIEnv *, jclass) {
    return (jint) audiobridge_get_selected_sample_rate();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_miclink_MainActivity_nativeGetSelectedChannels(JNIEnv *, jclass) {
    return (jint) audiobridge_get_selected_channels();
}
