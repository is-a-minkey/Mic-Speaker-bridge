#ifndef _MINIMAL_DLFCN_H_
#define _MINIMAL_DLFCN_H_

#ifdef __cplusplus
extern "C" {
#endif

#define RTLD_NOW 2

void *dlopen(const char *filename, int flags);
void *dlsym(void *handle, const char *symbol);
int dlclose(void *handle);
char *dlerror(void);

#ifdef __cplusplus
}
#endif

#endif /* _MINIMAL_DLFCN_H_ */
