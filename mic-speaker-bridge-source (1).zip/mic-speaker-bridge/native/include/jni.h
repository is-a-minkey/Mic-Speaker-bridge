/*
 * Minimal JNI shim.
 *
 * This project's native code only *receives* primitive (jint) parameters
 * from Java and never calls back into the JVM (no JNIEnv methods are
 * invoked), so we don't need the real, large jni.h from a JDK/NDK install.
 * We only need the small set of stable typedefs and export macros that
 * have been part of the JNI spec, unchanged, since JDK 1.1.
 */
#ifndef _MINIMAL_JNI_H_
#define _MINIMAL_JNI_H_

#include <stdint.h>

typedef uint8_t  jboolean;
typedef int8_t   jbyte;
typedef uint16_t jchar;
typedef int16_t  jshort;
typedef int32_t  jint;
typedef int64_t  jlong;
typedef float    jfloat;
typedef double   jdouble;

typedef jint jsize;

/* We never dereference JNIEnv/JavaVM, so opaque forward declarations are
 * sufficient and avoid needing the full ~230-method JNINativeInterface
 * table layout. */
struct JNIEnv_;
typedef struct JNIEnv_ JNIEnv;

struct JavaVM_;
typedef struct JavaVM_ JavaVM;

class _jobject {};
class _jclass : public _jobject {};
class _jstring : public _jobject {};
class _jthrowable : public _jobject {};
class _jarray : public _jobject {};

typedef _jobject*    jobject;
typedef _jclass*     jclass;
typedef _jstring*    jstring;
typedef _jthrowable* jthrowable;
typedef _jarray*     jarray;

#if defined(__ANDROID__) || defined(__linux__)
#define JNIEXPORT __attribute__((visibility("default")))
#define JNICALL
#else
#define JNIEXPORT
#define JNICALL
#endif

#endif /* _MINIMAL_JNI_H_ */
