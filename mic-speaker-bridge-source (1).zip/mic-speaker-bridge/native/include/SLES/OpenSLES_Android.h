/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* OpenSLES_Android.h - Android extensions (trimmed to what this project uses:
 *   SLAndroidSimpleBufferQueueItf, SLAndroidConfigurationItf,
 *   SLAndroidAcousticEchoCancellationItf, and the Android buffer-queue locator)
 */

#ifndef OPENSL_ESANDROID_H_
#define OPENSL_ESANDROID_H_

#include "SLES/OpenSLES.h"
#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------------------*/
/* Android AudioRecorder / Player data locators                              */
/*---------------------------------------------------------------------------*/

#define SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE ((SLuint32) 0x800007BD)

typedef struct SLDataLocator_AndroidSimpleBufferQueue_ {
    SLuint32 locatorType;
    SLuint32 numBuffers;
} SLDataLocator_AndroidSimpleBufferQueue;

/*---------------------------------------------------------------------------*/
/* Android Simple Buffer Queue Interface                                     */
/*---------------------------------------------------------------------------*/

extern SL_API const SLInterfaceID SL_IID_ANDROIDSIMPLEBUFFERQUEUE;

struct SLAndroidSimpleBufferQueueItf_;
typedef const struct SLAndroidSimpleBufferQueueItf_ * const * SLAndroidSimpleBufferQueueItf;

typedef void (SLAPIENTRY *slAndroidSimpleBufferQueueCallback) (
    SLAndroidSimpleBufferQueueItf caller,
    void *pContext
);

struct SLAndroidSimpleBufferQueueState_ {
    SLuint32 count;
    SLuint32 index;
};
typedef struct SLAndroidSimpleBufferQueueState_ SLAndroidSimpleBufferQueueState;

struct SLAndroidSimpleBufferQueueItf_ {
    SLresult (*Enqueue) (
        SLAndroidSimpleBufferQueueItf self,
        const void *pBuffer,
        SLuint32 size
    );
    SLresult (*Clear) (
        SLAndroidSimpleBufferQueueItf self
    );
    SLresult (*GetState) (
        SLAndroidSimpleBufferQueueItf self,
        SLAndroidSimpleBufferQueueState *pState
    );
    SLresult (*RegisterCallback) (
        SLAndroidSimpleBufferQueueItf self,
        slAndroidSimpleBufferQueueCallback callback,
        void* pContext
    );
};

/*---------------------------------------------------------------------------*/
/* Android Configuration Interface                                           */
/*---------------------------------------------------------------------------*/

extern SL_API const SLInterfaceID SL_IID_ANDROIDCONFIGURATION;

struct SLAndroidConfigurationItf_;
typedef const struct SLAndroidConfigurationItf_ * const * SLAndroidConfigurationItf;

struct SLAndroidConfigurationItf_ {
    SLresult (*SetConfiguration) (
        SLAndroidConfigurationItf self,
        const SLchar *configKey,
        const void *pConfigValue,
        SLuint32 valueSize
    );
    SLresult (*GetConfiguration) (
        SLAndroidConfigurationItf self,
        const SLchar *configKey,
        SLuint32 *pValueSize,
        void *pConfigValue
    );
    SLresult (*AcquireJavaProxy) (
        SLAndroidConfigurationItf self,
        SLuint32 proxyType,
        jobject *pProxyObj
    );
    SLresult (*ReleaseJavaProxy) (
        SLAndroidConfigurationItf self,
        SLuint32 proxyType
    );
};

/*---------------------------------------------------------------------------*/
/* Android Acoustic Echo Cancellation Interface                              */
/*---------------------------------------------------------------------------*/

extern SL_API const SLInterfaceID SL_IID_ANDROIDACOUSTICECHOCANCELLATION;

struct SLAndroidAcousticEchoCancellationItf_;
typedef const struct SLAndroidAcousticEchoCancellationItf_ * const * SLAndroidAcousticEchoCancellationItf;

struct SLAndroidAcousticEchoCancellationItf_ {
    SLresult (*SetEnabled) (
        SLAndroidAcousticEchoCancellationItf self,
        SLboolean enabled
    );
    SLresult (*IsEnabled) (
        SLAndroidAcousticEchoCancellationItf self
    );
};

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* OPENSL_ESANDROID_H_ */
